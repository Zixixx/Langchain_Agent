"""RAG components."""

